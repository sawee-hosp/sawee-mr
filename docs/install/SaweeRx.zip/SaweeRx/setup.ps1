﻿param([string]$Mode = 'install', [switch]$Startup)
# ติดตั้ง / ถอนการติดตั้ง ระบบยา รพ.สวี (เดิมชื่อ ตารางนัด รพ.สวี) (ต่อผู้ใช้ ไม่ต้องใช้สิทธิ์ admin)
$ErrorActionPreference = 'Stop'
$APP_NAME = 'ระบบยา รพ.สวี'
$OLD_NAME = 'ตารางนัด รพ.สวี'
$DEST     = Join-Path $env:LOCALAPPDATA 'SaweeAppt'
$SRC      = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'app'
$desktop  = [Environment]::GetFolderPath('Desktop')
$startupDir = [Environment]::GetFolderPath('Startup')
$programs = [Environment]::GetFolderPath('Programs')
$links    = @((Join-Path $desktop "$APP_NAME.lnk"), (Join-Path $programs "$APP_NAME.lnk"), (Join-Path $startupDir "$APP_NAME.lnk"))
$oldLinks = @((Join-Path $desktop "$OLD_NAME.lnk"), (Join-Path $programs "$OLD_NAME.lnk"), (Join-Path $startupDir "$OLD_NAME.lnk"))

function Stop-App {
  $f = Join-Path $DEST 'hwnd.txt'
  if (Test-Path $f) {
    Add-Type -Namespace SwSetup -Name U -MemberDefinition '[DllImport("user32.dll")] public static extern bool PostMessage(System.IntPtr h, uint m, System.IntPtr w, System.IntPtr l);'
    try { [void][SwSetup.U]::PostMessage([IntPtr][long]([IO.File]::ReadAllText($f).Trim()), 0x0010, [IntPtr]::Zero, [IntPtr]::Zero) } catch {}
    Start-Sleep -Seconds 3
  }
}
function New-Link($path) {
  $sh = New-Object -ComObject WScript.Shell
  $l = $sh.CreateShortcut($path)
  $l.TargetPath = "$env:WINDIR\System32\wscript.exe"
  $l.Arguments = '"' + (Join-Path $DEST 'start.vbs') + '"'
  $l.WorkingDirectory = $DEST
  $l.IconLocation = (Join-Path $DEST 'appt.ico') + ',0'
  $l.Description = $APP_NAME
  $l.Save()
}

function Stop-Browser {   # ปิด Chrome/Edge ที่เปิดด้วยโปรไฟล์ของแอปนี้เท่านั้น
  $prof = (Join-Path $DEST 'profile').ToLower()
  Get-WmiObject Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine.ToLower().Contains($prof) } | ForEach-Object { try { [void]$_.Terminate() } catch {} }
  Start-Sleep -Milliseconds 800
}

if ($Mode -eq 'uninstall') {
  Stop-App
  Stop-Browser
  foreach ($p in ($links + $oldLinks)) { Remove-Item $p -ErrorAction SilentlyContinue }
  Remove-Item $DEST -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "ถอนการติดตั้ง $APP_NAME เรียบร้อย"
  exit
}

Stop-App
foreach ($p in $oldLinks) { Remove-Item $p -ErrorAction SilentlyContinue }   # ลบไอคอนชื่อเดิม
# ปิด Chrome ของแอปที่ค้างอยู่ เพื่อให้ค่าใหม่ (ลิงก์/สิทธิ์เครือข่าย รพ.) มีผลทันที
$prof = (Join-Path $DEST 'profile').ToLower()
Get-WmiObject Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine.ToLower().Contains($prof) } | ForEach-Object { try { [void]$_.Terminate() } catch {} }
Start-Sleep -Milliseconds 800
New-Item -ItemType Directory -Force -Path $DEST | Out-Null
Copy-Item -Path (Join-Path $SRC '*') -Destination $DEST -Recurse -Force
New-Link $links[0]
New-Link $links[1]
if ($Startup) { New-Link $links[2] } else { Remove-Item $links[2] -ErrorAction SilentlyContinue }
Write-Host "ติดตั้ง $APP_NAME เรียบร้อย — มีไอคอนบน Desktop แล้ว"
Start-Process "$env:WINDIR\System32\wscript.exe" -ArgumentList ('"' + (Join-Path $DEST 'start.vbs') + '"')
