﻿<#  ระบบยา รพ.สวี (ตารางนัด + ระบบยา) — หน้าต่างลอยชิดขวา (Always on top)
    เปิดจาก icon บน Desktop · ซ่อน/แสดงด้วยปุ่มลัด หรือคลิก icon ที่มุมจอข้างนาฬิกา
#>

# ================= ตั้งค่า =================
$URL        = 'https://sawee-hosp.github.io/sawee-mr/docs/'   # หน้าแรก (ตารางนัด + แถบ ระบบยา) — ที่อยู่ระบบยาตั้งในหน้านี้
$WIDTH      = 320            # ความกว้างหน้าต่าง (px ตามขนาดตัวอักษรของ Windows)
$SIDE       = 'right'        # 'right' = ชิดขวา | 'left' = ชิดซ้าย
$HOTKEY_MOD = 0x0003         # 0x0001 Alt + 0x0002 Ctrl  →  Ctrl+Alt
$HOTKEY_VK  = 0x41           # ปุ่ม A   →  Ctrl+Alt+A = ซ่อน/แสดง
$HOTKEY_TXT = 'Ctrl+Alt+A'
$APP_NAME   = 'ระบบยา รพ.สวี'
# ==========================================

$ErrorActionPreference = 'Stop'
$BASE    = Join-Path $env:LOCALAPPDATA 'SaweeAppt'
$PROFILE_DIR = Join-Path $BASE 'profile'
$HWND_FILE   = Join-Path $BASE 'hwnd.txt'
$HERE = Split-Path -Parent $MyInvocation.MyCommand.Path
$ICON_FILE   = Join-Path $HERE 'appt.ico'
$FIRST_FLAG  = Join-Path $BASE 'shown_tip.txt'
New-Item -ItemType Directory -Force -Path $BASE | Out-Null

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public static class SwWin {
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);

  /* หาหน้าต่างหลักของ Chrome ที่เป็นของ process ในรายการ (โปรไฟล์ของแอปนี้เท่านั้น) */
  public static IntPtr Find(int[] pids) {
    HashSet<int> set = new HashSet<int>(pids);
    IntPtr found = IntPtr.Zero;
    EnumWindows(delegate (IntPtr h, IntPtr l) {
      uint pid;
      GetWindowThreadProcessId(h, out pid);
      if (!set.Contains((int)pid)) return true;
      if (!IsWindowVisible(h)) return true;
      if (GetWindow(h, 4) != IntPtr.Zero) return true;            // ข้ามหน้าต่างย่อย/popup
      if (GetWindowTextLength(h) == 0) return true;
      StringBuilder sb = new StringBuilder(64);
      GetClassName(h, sb, 64);
      if (sb.ToString() != "Chrome_WidgetWin_1") return true;
      found = h;
      return false;
    }, IntPtr.Zero);
    return found;
  }
}

/* ปุ่มลัดทั้งระบบ (กดได้แม้กำลังใช้ HOSxP อยู่) */
public class SwHotkey : NativeWindow {
  [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
  [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
  public event EventHandler Pressed;
  public bool Ok;
  public SwHotkey(uint mod, uint vk) {
    CreateHandle(new CreateParams());
    Ok = RegisterHotKey(Handle, 1, mod | 0x4000, vk);              // 0x4000 = ไม่ยิงซ้ำตอนกดค้าง
  }
  protected override void WndProc(ref Message m) {
    if (m.Msg == 0x0312 && Pressed != null) Pressed(this, EventArgs.Empty);
    base.WndProc(ref m);
  }
  public void Release() { UnregisterHotKey(Handle, 1); DestroyHandle(); }
}
'@

[void][SwWin]::SetProcessDPIAware()
$TOPMOST = [IntPtr](-1); $NOTOPMOST = [IntPtr](-2)
$SWP_NOSIZE = 0x1; $SWP_NOMOVE = 0x2; $SWP_NOACTIVATE = 0x10; $SWP_SHOWWINDOW = 0x40

function Get-SavedHwnd {
  if (Test-Path $HWND_FILE) {
    $v = 0L
    if ([long]::TryParse(([IO.File]::ReadAllText($HWND_FILE)).Trim(), [ref]$v)) {
      $h = [IntPtr]$v
      if ([SwWin]::IsWindow($h)) { return $h }
    }
  }
  return [IntPtr]::Zero
}

function Show-AppWindow([IntPtr]$h) {
  if ([SwWin]::IsIconic($h)) { [void][SwWin]::ShowWindow($h, 9) } else { [void][SwWin]::ShowWindow($h, 5) }
  [void][SwWin]::SetWindowPos($h, $TOPMOST, 0, 0, 0, 0, ($SWP_NOMOVE -bor $SWP_NOSIZE -bor $SWP_SHOWWINDOW))
  [void][SwWin]::SetForegroundWindow($h)
}

# ---------- เปิดซ้ำ: ถ้าโปรแกรมทำงานอยู่แล้ว ให้แค่ดึงหน้าต่างขึ้นมาแล้วจบ ----------
$mutex = New-Object System.Threading.Mutex($false, 'Local\SaweeApptController')
if (-not $mutex.WaitOne(0)) {
  $h = Get-SavedHwnd
  if ($h -ne [IntPtr]::Zero) { Show-AppWindow $h }
  exit
}

# ---------- หา Chrome ----------
function Find-Browser {
  $c = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  foreach ($k in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
                 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe') {
    try { $c += (Get-ItemProperty $k -ErrorAction Stop).'(default)' } catch {}
  }
  foreach ($p in $c) { if ($p -and (Test-Path $p)) { return $p } }
  # ไม่มี Chrome → ใช้ Edge แทน (มีในทุกเครื่อง Windows 10/11)
  foreach ($p in "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
                 "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") {
    if (Test-Path $p) { return $p }
  }
  return $null
}
$BROWSER = Find-Browser
if (-not $BROWSER) {
  [System.Windows.Forms.MessageBox]::Show('ไม่พบ Google Chrome ในเครื่องนี้', $APP_NAME) | Out-Null
  exit
}
$PROC_NAME = [IO.Path]::GetFileName($BROWSER)

function Get-AppPids {
  $needle = $PROFILE_DIR.ToLower()
  @(Get-WmiObject Win32_Process -Filter "Name='$PROC_NAME'" |
    Where-Object { $_.CommandLine -and $_.CommandLine.ToLower().Contains($needle) } |
    ForEach-Object { [int]$_.ProcessId })
}

# ---------- ตำแหน่ง/ขนาด ----------
function Get-Geometry {
  $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea       # พื้นที่จอไม่รวม taskbar
  $g = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
  $scale = $g.DpiX / 96.0; $g.Dispose()
  $w = [int][Math]::Round($WIDTH * $scale)
  $x = if ($SIDE -eq 'left') { $wa.Left } else { $wa.Right - $w }
  return @{ X = $x; Y = $wa.Top; W = $w; H = $wa.Height }
}
function Place-Window([IntPtr]$h) {
  $g = Get-Geometry
  if ([SwWin]::IsIconic($h)) { [void][SwWin]::ShowWindow($h, 9) }
  [void][SwWin]::SetWindowPos($h, $TOPMOST, $g.X, $g.Y, $g.W, $g.H, $SWP_SHOWWINDOW)
}

# ---------- เปิด Chrome แบบหน้าต่างแอป (โปรไฟล์แยก) ----------
$hwnd = [IntPtr]::Zero
$pids = Get-AppPids
if ($pids.Count -gt 0) { $hwnd = [SwWin]::Find([int[]]$pids) }
# ---------- ตั้งค่าโปรไฟล์: ไม่ถามจำรหัสผ่าน / ไม่กรอกอัตโนมัติ / ไม่กู้หน้าเดิมหลังปิดเครื่อง ----------
function Set-Prop($o, [string]$k, $v) { if ($o.PSObject.Properties[$k]) { $o.$k = $v } else { $o | Add-Member -NotePropertyName $k -NotePropertyValue $v } }
function Get-Obj($o, [string]$k) { if (-not $o.PSObject.Properties[$k] -or -not ($o.$k -is [System.Management.Automation.PSCustomObject])) { Set-Prop $o $k (New-Object PSObject) }; return $o.$k }
function Set-ChromePrefs {
  try {
    $dir = Join-Path $PROFILE_DIR 'Default'; New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $f = Join-Path $dir 'Preferences'; $j = $null
    if (Test-Path $f) { try { $j = [IO.File]::ReadAllText($f) | ConvertFrom-Json } catch { $j = $null } }
    if (-not $j) { $j = New-Object PSObject }
    Set-Prop $j 'credentials_enable_service' $false
    Set-Prop $j 'credentials_enable_autosignin' $false
    $pf = Get-Obj $j 'profile'
    Set-Prop $pf 'password_manager_enabled' $false
    Set-Prop $pf 'exit_type' 'Normal'
    Set-Prop $pf 'exited_cleanly' $true
    $af = Get-Obj $j 'autofill'
    Set-Prop $af 'profile_enabled' $false
    Set-Prop $af 'credit_card_enabled' $false
    $se = Get-Obj $j 'session'
    Set-Prop $se 'restore_on_startup' 5
    [IO.File]::WriteAllText($f, ($j | ConvertTo-Json -Depth 60 -Compress), (New-Object System.Text.UTF8Encoding $false))
  } catch {}
}

if ($hwnd -eq [IntPtr]::Zero) {
  Set-ChromePrefs
  $g = Get-Geometry
  $chromeArgs = @(
    "--app=$URL",
    "--user-data-dir=`"$PROFILE_DIR`"",
    "--window-size=$($g.W),$($g.H)",
    "--window-position=$($g.X),$($g.Y)",
    '--no-first-run', '--no-default-browser-check',
    '--disable-extensions', '--disable-features=Translate,LocalNetworkAccessChecks,BlockInsecurePrivateNetworkRequests,PasswordManagerOnboarding,PasswordLeakDetection'
  )
  Start-Process -FilePath $BROWSER -ArgumentList $chromeArgs | Out-Null
  $deadline = (Get-Date).AddSeconds(40)
  while ($hwnd -eq [IntPtr]::Zero -and (Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 600
    $pids = Get-AppPids
    if ($pids.Count -gt 0) { $hwnd = [SwWin]::Find([int[]]$pids) }
  }
}
if ($hwnd -eq [IntPtr]::Zero) {
  [System.Windows.Forms.MessageBox]::Show('เปิดหน้าต่างไม่สำเร็จ ลองดับเบิลคลิกไอคอนอีกครั้ง', $APP_NAME) | Out-Null
  exit
}
Set-Content -Path $HWND_FILE -Value ([long]$hwnd) -Encoding ASCII
Place-Window $hwnd
$script:hwnd = $hwnd
$script:onTop = $true
$script:placeAgain = 3          # จัดตำแหน่งซ้ำอีก 3 รอบแรก เผื่อ Chrome ปรับขนาดตัวเองตอนโหลดหน้าเว็บ

# ---------- คำสั่ง ----------
function Toggle-Window {
  $h = $script:hwnd
  if ([SwWin]::IsWindowVisible($h) -and -not [SwWin]::IsIconic($h)) {
    [void][SwWin]::ShowWindow($h, 0)                                  # ซ่อน (หายจาก taskbar ด้วย)
  } else {
    Show-AppWindow $h
  }
}
function Close-App {
  try { $script:timer.Stop() } catch {}
  try { $script:hk.Release() } catch {}
  if ([SwWin]::IsWindow($script:hwnd)) {
    [void][SwWin]::ShowWindow($script:hwnd, 5)
    [void][SwWin]::PostMessage($script:hwnd, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero)   # WM_CLOSE
  }
  $script:tray.Visible = $false
  $script:tray.Dispose()
  Remove-Item $HWND_FILE -ErrorAction SilentlyContinue
  [System.Windows.Forms.Application]::ExitThread()
}

# ---------- ไอคอนที่มุมจอ (ข้างนาฬิกา) ----------
$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Icon = if (Test-Path $ICON_FILE) { New-Object System.Drawing.Icon $ICON_FILE } else { [System.Drawing.SystemIcons]::Application }
$tray.Text = "$APP_NAME  ($HOTKEY_TXT ซ่อน/แสดง)"
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miToggle = $menu.Items.Add("ซ่อน / แสดง   ($HOTKEY_TXT)")
$miPlace  = $menu.Items.Add('จัดหน้าต่างชิดขอบจอใหม่')
$miTop    = New-Object System.Windows.Forms.ToolStripMenuItem 'ลอยอยู่บนสุดเสมอ'
$miTop.Checked = $true
[void]$menu.Items.Add($miTop)
[void]$menu.Items.Add('-')
$miExit   = $menu.Items.Add('ปิดโปรแกรม')
$tray.ContextMenuStrip = $menu
$tray.Visible = $true
$script:tray = $tray

$miToggle.add_Click({ Toggle-Window })
$miPlace.add_Click({ Show-AppWindow $script:hwnd; Place-Window $script:hwnd })
$miTop.add_Click({
  $script:onTop = -not $script:onTop
  $miTop.Checked = $script:onTop
  $z = if ($script:onTop) { $TOPMOST } else { $NOTOPMOST }
  [void][SwWin]::SetWindowPos($script:hwnd, $z, 0, 0, 0, 0, ($SWP_NOMOVE -bor $SWP_NOSIZE -bor $SWP_NOACTIVATE))
})
$miExit.add_Click({ Close-App })
$tray.add_MouseClick({ param($s, $e) if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) { Toggle-Window } })

# ---------- ปุ่มลัด ----------
$hk = New-Object SwHotkey([uint32]$HOTKEY_MOD, [uint32]$HOTKEY_VK)
$script:hk = $hk
$hk.add_Pressed({ Toggle-Window })
if ($hk.Ok) {
  if (-not (Test-Path $FIRST_FLAG)) {
    Set-Content -Path $FIRST_FLAG -Value '1'
    $tray.ShowBalloonTip(4000, $APP_NAME, "กด $HOTKEY_TXT เพื่อซ่อน/แสดง หรือคลิกไอคอนนี้", [System.Windows.Forms.ToolTipIcon]::Info)
  }
} else {
  $tray.ShowBalloonTip(4000, $APP_NAME, "ปุ่มลัด $HOTKEY_TXT ถูกโปรแกรมอื่นใช้อยู่ — คลิกไอคอนนี้เพื่อซ่อน/แสดงแทน", [System.Windows.Forms.ToolTipIcon]::Warning)
}

# ---------- เฝ้าหน้าต่าง: ย้ำ "บนสุด" ทุก 2 วินาที / ปิด Chrome แล้วโปรแกรมนี้ปิดตาม ----------
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.add_Tick({
  if (-not [SwWin]::IsWindow($script:hwnd)) { Close-App; return }
  if ($script:placeAgain -gt 0) { $script:placeAgain--; Place-Window $script:hwnd; return }
  if ($script:onTop -and [SwWin]::IsWindowVisible($script:hwnd)) {
    [void][SwWin]::SetWindowPos($script:hwnd, $TOPMOST, 0, 0, 0, 0, ($SWP_NOMOVE -bor $SWP_NOSIZE -bor $SWP_NOACTIVATE))
  }
})
$script:timer = $timer
$timer.Start()

[System.Windows.Forms.Application]::Run()
$mutex.ReleaseMutex()
