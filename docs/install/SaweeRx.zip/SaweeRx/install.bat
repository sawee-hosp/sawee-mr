@echo off
title Sawee Rx - Install
cd /d "%~dp0"
echo.
echo  Installing "Sawee Rx" ...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" install -Startup
echo.
echo  Done. This window will close.
timeout /t 3 >nul
