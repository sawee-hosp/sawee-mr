@echo off
title Sawee Rx - Uninstall
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" uninstall
echo.
echo  Done. This window will close.
timeout /t 3 >nul
